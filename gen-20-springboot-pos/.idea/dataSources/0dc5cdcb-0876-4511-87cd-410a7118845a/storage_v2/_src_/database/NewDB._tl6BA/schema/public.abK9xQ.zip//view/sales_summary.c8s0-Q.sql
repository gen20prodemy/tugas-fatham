create view sales_summary(std_id, total_sales) as
SELECT std_id,
       sum(transaction_price) AS total_sales
FROM transactions
GROUP BY transaction_id;

alter table sales_summary
    owner to postgres;

